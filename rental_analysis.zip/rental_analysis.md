# San Francisco Housing Rental Analysis

In this assignment, you will perform basic analysis for the San Francisco Housing Market to allow potential real estate investors to choose rental investment properties. 


```python
# initial imports
import os
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import hvplot.pandas
from pathlib import Path
from dotenv import load_dotenv

%matplotlib inline
```


```python
# Read the Mapbox API key
load_dotenv()
mapbox_token = os.getenv("pk.eyJ1IjoiZmF6bGVoYW1lZW0iLCJhIjoiY2tneTdreWV4MGIyZTJ1bXNtd3E4dTNwZCJ9.V-zQBku8Dcjlk14FBqxPUg")
```

## Load Data


```python
# Read the census data into a Pandas DataFrame
file_path = Path("Data/sfo_neighborhoods_census_data.csv")
sfo_data = pd.read_csv(file_path)
sfo_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>neighborhood</th>
      <th>sale_price_sqr_foot</th>
      <th>housing_units</th>
      <th>gross_rent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2010</td>
      <td>Alamo Square</td>
      <td>291.182945</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2010</td>
      <td>Anza Vista</td>
      <td>267.932583</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2010</td>
      <td>Bayview</td>
      <td>170.098665</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2010</td>
      <td>Buena Vista Park</td>
      <td>347.394919</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2010</td>
      <td>Central Richmond</td>
      <td>319.027623</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
  </tbody>
</table>
</div>



- - - 

## Housing Units Per Year

In this section, you will calculate the number of housing units per year and visualize the results as a bar chart using the Pandas plot function. 

Hint: Use the Pandas groupby function

Optional challenge: Use the min, max, and std to scale the y limits of the chart.


```python
load_data = (sfo_data[["year", "housing_units"]])
load_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>housing_units</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2010</td>
      <td>372560</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>367</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>368</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>369</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>370</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>371</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>372</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>373</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>374</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>375</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>376</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>377</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>378</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>379</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>380</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>381</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>382</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>383</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>384</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>385</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>386</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>387</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>388</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>389</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>390</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>391</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>392</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>393</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>394</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>395</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
    <tr>
      <th>396</th>
      <td>2016</td>
      <td>384242</td>
    </tr>
  </tbody>
</table>
<p>397 rows × 2 columns</p>
</div>




```python
# Calculate the mean number of housing units per year (hint: use groupby) 
load_data1 = (load_data.groupby("year")).mean()
load_data1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>housing_units</th>
    </tr>
    <tr>
      <th>year</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2010</th>
      <td>372560</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>374507</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>376454</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>378401</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>380348</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>382295</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>384242</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
# Use the Pandas plot function to plot the average housing units per year.
# Note: You will need to manually adjust the y limit of the chart using the min and max values from above.

load_data1.hvplot.bar(x='year', y = 'housing_units', rot=90, ylim =(370000, 387500)).opts(yformatter="%.0f")
```




<div id='2965'>





  <div class="bk-root" id="d76115a2-f9ad-42fd-944f-e9a0d87f9847" data-root-id="2965"></div>
</div>
<script type="application/javascript">(function(root) {
  function embed_document(root) {
  var docs_json = {"30f237ea-877d-4dd6-b45e-4f8504221d45":{"roots":{"references":[{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05328","sizing_mode":"stretch_width"},"id":"3028","type":"Spacer"},{"attributes":{},"id":"3020","type":"UnionRenderers"},{"attributes":{"factors":["2010","2011","2012","2013","2014","2015","2016"],"tags":[[["year","year",null]]]},"id":"2967","type":"FactorRange"},{"attributes":{},"id":"3000","type":"Selection"},{"attributes":{"end":387500,"reset_end":387500,"reset_start":370000,"start":370000,"tags":[[["housing_units","housing_units",null]]]},"id":"2968","type":"Range1d"},{"attributes":{"align":null,"below":[{"id":"2979"}],"center":[{"id":"2981"},{"id":"2985"}],"left":[{"id":"2982"}],"margin":null,"min_border_bottom":10,"min_border_left":10,"min_border_right":10,"min_border_top":10,"plot_height":300,"plot_width":700,"renderers":[{"id":"3005"}],"sizing_mode":"fixed","title":{"id":"2971"},"toolbar":{"id":"2992"},"x_range":{"id":"2967"},"x_scale":{"id":"2975"},"y_range":{"id":"2968"},"y_scale":{"id":"2977"}},"id":"2970","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"2986","type":"SaveTool"},{"attributes":{},"id":"2975","type":"CategoricalScale"},{"attributes":{},"id":"2988","type":"WheelZoomTool"},{"attributes":{"children":[{"id":"2966"},{"id":"2970"},{"id":"3028"}],"margin":[0,0,0,0],"name":"Row05323","tags":["embedded"]},"id":"2965","type":"Row"},{"attributes":{"text":"","text_color":{"value":"black"},"text_font_size":{"value":"12pt"}},"id":"2971","type":"Title"},{"attributes":{"format":"%.0f"},"id":"3007","type":"PrintfTickFormatter"},{"attributes":{},"id":"2987","type":"PanTool"},{"attributes":{"overlay":{"id":"2991"}},"id":"2989","type":"BoxZoomTool"},{"attributes":{},"id":"3008","type":"CategoricalTickFormatter"},{"attributes":{"fill_color":{"value":"#1f77b3"},"top":{"field":"housing_units"},"width":{"value":0.8},"x":{"field":"year"}},"id":"3002","type":"VBar"},{"attributes":{},"id":"2977","type":"LinearScale"},{"attributes":{"callback":null,"renderers":[{"id":"3005"}],"tags":["hv_created"],"tooltips":[["year","@{year}"],["housing_units","@{housing_units}"]]},"id":"2969","type":"HoverTool"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05327","sizing_mode":"stretch_width"},"id":"2966","type":"Spacer"},{"attributes":{},"id":"2990","type":"ResetTool"},{"attributes":{"fill_alpha":{"value":0.2},"fill_color":{"value":"#1f77b3"},"line_alpha":{"value":0.2},"top":{"field":"housing_units"},"width":{"value":0.8},"x":{"field":"year"}},"id":"3004","type":"VBar"},{"attributes":{"axis_label":"year","bounds":"auto","formatter":{"id":"3008"},"major_label_orientation":1.5707963267948966,"ticker":{"id":"2980"}},"id":"2979","type":"CategoricalAxis"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b3"},"line_alpha":{"value":0.1},"top":{"field":"housing_units"},"width":{"value":0.8},"x":{"field":"year"}},"id":"3003","type":"VBar"},{"attributes":{"axis":{"id":"2979"},"grid_line_color":null,"ticker":null},"id":"2981","type":"Grid"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","top_units":"screen"},"id":"2991","type":"BoxAnnotation"},{"attributes":{"data_source":{"id":"2999"},"glyph":{"id":"3002"},"hover_glyph":null,"muted_glyph":{"id":"3004"},"nonselection_glyph":{"id":"3003"},"selection_glyph":null,"view":{"id":"3006"}},"id":"3005","type":"GlyphRenderer"},{"attributes":{},"id":"2980","type":"CategoricalTicker"},{"attributes":{"axis_label":"housing_units","bounds":"auto","formatter":{"id":"3007"},"major_label_orientation":"horizontal","ticker":{"id":"2983"}},"id":"2982","type":"LinearAxis"},{"attributes":{"source":{"id":"2999"}},"id":"3006","type":"CDSView"},{"attributes":{},"id":"2983","type":"BasicTicker"},{"attributes":{"axis":{"id":"2982"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"2985","type":"Grid"},{"attributes":{"active_drag":"auto","active_inspect":"auto","active_multi":null,"active_scroll":"auto","active_tap":"auto","tools":[{"id":"2969"},{"id":"2986"},{"id":"2987"},{"id":"2988"},{"id":"2989"},{"id":"2990"}]},"id":"2992","type":"Toolbar"},{"attributes":{"data":{"housing_units":[372560,374507,376454,378401,380348,382295,384242],"year":["2010","2011","2012","2013","2014","2015","2016"]},"selected":{"id":"3000"},"selection_policy":{"id":"3020"}},"id":"2999","type":"ColumnDataSource"}],"root_ids":["2965"]},"title":"Bokeh Application","version":"2.1.1"}};
  var render_items = [{"docid":"30f237ea-877d-4dd6-b45e-4f8504221d45","root_ids":["2965"],"roots":{"2965":"d76115a2-f9ad-42fd-944f-e9a0d87f9847"}}];
  root.Bokeh.embed.embed_items_notebook(docs_json, render_items);
  }
if (root.Bokeh !== undefined) {
    embed_document(root);
  } else {
    var attempts = 0;
    var timer = setInterval(function(root) {
      if (root.Bokeh !== undefined) {
        clearInterval(timer);
        embed_document(root);
      } else if (document.readyState == "complete") {
        attempts++;
        if (attempts > 100) {
          clearInterval(timer);
          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
        }
      }
    }, 10, root)
  }
})(window);</script>



- - - 


```python

```

## Average Prices per Square Foot

In this section, you will calculate the average gross rent and average sales price for each year. Plot the results as a line chart.

### Average Gross Rent in San Francisco Per Year


```python
# Calculate the average gross rent and average sale price per square foot
load_data2 = (sfo_data[["year", "sale_price_sqr_foot", "gross_rent"]]).groupby("year").mean()
load_data2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_price_sqr_foot</th>
      <th>gross_rent</th>
    </tr>
    <tr>
      <th>year</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2010</th>
      <td>369.344353</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>341.903429</td>
      <td>1530</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>399.389968</td>
      <td>2324</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>483.600304</td>
      <td>2971</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>556.277273</td>
      <td>3528</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>632.540352</td>
      <td>3739</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>697.643709</td>
      <td>4390</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot the Average Gross Rent per Year as a Line Chart 
load_data2.hvplot(x = 'year', y = 'gross_rent', label = 'Average Gross Rent in San Francisco')
```




<div id='3065'>





  <div class="bk-root" id="95fcf76e-c911-4b2a-a3d8-d59e7f6159b1" data-root-id="3065"></div>
</div>
<script type="application/javascript">(function(root) {
  function embed_document(root) {
  var docs_json = {"ca32929d-6f3e-4cbe-8aa1-0b25c52cdb28":{"roots":{"references":[{"attributes":{"text":"Average Gross Rent in San Francisco","text_color":{"value":"black"},"text_font_size":{"value":"12pt"}},"id":"3071","type":"Title"},{"attributes":{"line_alpha":0.1,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"gross_rent"}},"id":"3104","type":"Line"},{"attributes":{},"id":"3080","type":"BasicTicker"},{"attributes":{},"id":"3108","type":"BasicTickFormatter"},{"attributes":{"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"gross_rent"}},"id":"3103","type":"Line"},{"attributes":{},"id":"3119","type":"UnionRenderers"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05477","sizing_mode":"stretch_width"},"id":"3066","type":"Spacer"},{"attributes":{"end":2016.0,"reset_end":2016.0,"reset_start":2010.0,"start":2010.0,"tags":[[["year","year",null]]]},"id":"3067","type":"Range1d"},{"attributes":{},"id":"3088","type":"PanTool"},{"attributes":{"data_source":{"id":"3100"},"glyph":{"id":"3103"},"hover_glyph":null,"muted_glyph":{"id":"3105"},"nonselection_glyph":{"id":"3104"},"selection_glyph":null,"view":{"id":"3107"}},"id":"3106","type":"GlyphRenderer"},{"attributes":{"end":4705.1,"reset_end":4705.1,"reset_start":923.9,"start":923.9,"tags":[[["gross_rent","gross_rent",null]]]},"id":"3068","type":"Range1d"},{"attributes":{"overlay":{"id":"3092"}},"id":"3090","type":"BoxZoomTool"},{"attributes":{},"id":"3101","type":"Selection"},{"attributes":{"data":{"gross_rent":[1239,1530,2324,2971,3528,3739,4390],"year":[2010,2011,2012,2013,2014,2015,2016]},"selected":{"id":"3101"},"selection_policy":{"id":"3119"}},"id":"3100","type":"ColumnDataSource"},{"attributes":{"axis_label":"year","bounds":"auto","formatter":{"id":"3108"},"major_label_orientation":"horizontal","ticker":{"id":"3080"}},"id":"3079","type":"LinearAxis"},{"attributes":{"children":[{"id":"3066"},{"id":"3070"},{"id":"3128"}],"margin":[0,0,0,0],"name":"Row05473","tags":["embedded"]},"id":"3065","type":"Row"},{"attributes":{"callback":null,"renderers":[{"id":"3106"}],"tags":["hv_created"],"tooltips":[["year","@{year}"],["gross_rent","@{gross_rent}"]]},"id":"3069","type":"HoverTool"},{"attributes":{"line_alpha":0.2,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"gross_rent"}},"id":"3105","type":"Line"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","top_units":"screen"},"id":"3092","type":"BoxAnnotation"},{"attributes":{},"id":"3075","type":"LinearScale"},{"attributes":{},"id":"3110","type":"BasicTickFormatter"},{"attributes":{"source":{"id":"3100"}},"id":"3107","type":"CDSView"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05478","sizing_mode":"stretch_width"},"id":"3128","type":"Spacer"},{"attributes":{"axis_label":"gross_rent","bounds":"auto","formatter":{"id":"3110"},"major_label_orientation":"horizontal","ticker":{"id":"3084"}},"id":"3083","type":"LinearAxis"},{"attributes":{"axis":{"id":"3079"},"grid_line_color":null,"ticker":null},"id":"3082","type":"Grid"},{"attributes":{},"id":"3087","type":"SaveTool"},{"attributes":{},"id":"3091","type":"ResetTool"},{"attributes":{"axis":{"id":"3083"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"3086","type":"Grid"},{"attributes":{"align":null,"below":[{"id":"3079"}],"center":[{"id":"3082"},{"id":"3086"}],"left":[{"id":"3083"}],"margin":null,"min_border_bottom":10,"min_border_left":10,"min_border_right":10,"min_border_top":10,"plot_height":300,"plot_width":700,"renderers":[{"id":"3106"}],"sizing_mode":"fixed","title":{"id":"3071"},"toolbar":{"id":"3093"},"x_range":{"id":"3067"},"x_scale":{"id":"3075"},"y_range":{"id":"3068"},"y_scale":{"id":"3077"}},"id":"3070","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"3077","type":"LinearScale"},{"attributes":{},"id":"3089","type":"WheelZoomTool"},{"attributes":{"active_drag":"auto","active_inspect":"auto","active_multi":null,"active_scroll":"auto","active_tap":"auto","tools":[{"id":"3069"},{"id":"3087"},{"id":"3088"},{"id":"3089"},{"id":"3090"},{"id":"3091"}]},"id":"3093","type":"Toolbar"},{"attributes":{},"id":"3084","type":"BasicTicker"}],"root_ids":["3065"]},"title":"Bokeh Application","version":"2.1.1"}};
  var render_items = [{"docid":"ca32929d-6f3e-4cbe-8aa1-0b25c52cdb28","root_ids":["3065"],"roots":{"3065":"95fcf76e-c911-4b2a-a3d8-d59e7f6159b1"}}];
  root.Bokeh.embed.embed_items_notebook(docs_json, render_items);
  }
if (root.Bokeh !== undefined) {
    embed_document(root);
  } else {
    var attempts = 0;
    var timer = setInterval(function(root) {
      if (root.Bokeh !== undefined) {
        clearInterval(timer);
        embed_document(root);
      } else if (document.readyState == "complete") {
        attempts++;
        if (attempts > 100) {
          clearInterval(timer);
          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
        }
      }
    }, 10, root)
  }
})(window);</script>



### Average Sales Price per Year


```python
# Plot the Average Sales Price per Year as a line chart
load_data2.hvplot(x = 'year', y = 'sale_price_sqr_foot', label = 'Average Sale Price per Square Foot in San Francisco')
```




<div id='3170'>





  <div class="bk-root" id="dedf9170-6329-4eb1-9419-5767e9c7b18f" data-root-id="3170"></div>
</div>
<script type="application/javascript">(function(root) {
  function embed_document(root) {
  var docs_json = {"2f427bad-7663-4037-a99f-e1bfa28f3f23":{"roots":{"references":[{"attributes":{"end":733.2177371101802,"reset_end":733.2177371101802,"reset_start":306.3294011864627,"start":306.3294011864627,"tags":[[["sale_price_sqr_foot","sale_price_sqr_foot",null]]]},"id":"3173","type":"Range1d"},{"attributes":{},"id":"3215","type":"BasicTickFormatter"},{"attributes":{},"id":"3185","type":"BasicTicker"},{"attributes":{"children":[{"id":"3171"},{"id":"3175"},{"id":"3233"}],"margin":[0,0,0,0],"name":"Row05651","tags":["embedded"]},"id":"3170","type":"Row"},{"attributes":{"data":{"sale_price_sqr_foot":{"__ndarray__":"tQKjeIIVd0Do7CdydF51QGdijk899nhAaBKk2Jo5fkDGKCTbN2KBQPETFqRSxINAUB33UCbNhUA=","dtype":"float64","order":"little","shape":[7]},"year":[2010,2011,2012,2013,2014,2015,2016]},"selected":{"id":"3206"},"selection_policy":{"id":"3224"}},"id":"3205","type":"ColumnDataSource"},{"attributes":{},"id":"3189","type":"BasicTicker"},{"attributes":{"axis":{"id":"3188"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"3191","type":"Grid"},{"attributes":{"callback":null,"renderers":[{"id":"3211"}],"tags":["hv_created"],"tooltips":[["year","@{year}"],["sale_price_sqr_foot","@{sale_price_sqr_foot}"]]},"id":"3174","type":"HoverTool"},{"attributes":{"axis_label":"year","bounds":"auto","formatter":{"id":"3213"},"major_label_orientation":"horizontal","ticker":{"id":"3185"}},"id":"3184","type":"LinearAxis"},{"attributes":{"data_source":{"id":"3205"},"glyph":{"id":"3208"},"hover_glyph":null,"muted_glyph":{"id":"3210"},"nonselection_glyph":{"id":"3209"},"selection_glyph":null,"view":{"id":"3212"}},"id":"3211","type":"GlyphRenderer"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05655","sizing_mode":"stretch_width"},"id":"3171","type":"Spacer"},{"attributes":{"line_alpha":0.1,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3209","type":"Line"},{"attributes":{"source":{"id":"3205"}},"id":"3212","type":"CDSView"},{"attributes":{"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3208","type":"Line"},{"attributes":{"align":null,"below":[{"id":"3184"}],"center":[{"id":"3187"},{"id":"3191"}],"left":[{"id":"3188"}],"margin":null,"min_border_bottom":10,"min_border_left":10,"min_border_right":10,"min_border_top":10,"plot_height":300,"plot_width":700,"renderers":[{"id":"3211"}],"sizing_mode":"fixed","title":{"id":"3176"},"toolbar":{"id":"3198"},"x_range":{"id":"3172"},"x_scale":{"id":"3180"},"y_range":{"id":"3173"},"y_scale":{"id":"3182"}},"id":"3175","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"3192","type":"SaveTool"},{"attributes":{},"id":"3180","type":"LinearScale"},{"attributes":{},"id":"3194","type":"WheelZoomTool"},{"attributes":{},"id":"3193","type":"PanTool"},{"attributes":{},"id":"3224","type":"UnionRenderers"},{"attributes":{"text":"Average Sale Price per Square Foot in San Francisco","text_color":{"value":"black"},"text_font_size":{"value":"12pt"}},"id":"3176","type":"Title"},{"attributes":{"overlay":{"id":"3197"}},"id":"3195","type":"BoxZoomTool"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","top_units":"screen"},"id":"3197","type":"BoxAnnotation"},{"attributes":{},"id":"3182","type":"LinearScale"},{"attributes":{},"id":"3196","type":"ResetTool"},{"attributes":{"line_alpha":0.2,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3210","type":"Line"},{"attributes":{},"id":"3213","type":"BasicTickFormatter"},{"attributes":{"axis_label":"sale_price_sqr_foot","bounds":"auto","formatter":{"id":"3215"},"major_label_orientation":"horizontal","ticker":{"id":"3189"}},"id":"3188","type":"LinearAxis"},{"attributes":{"active_drag":"auto","active_inspect":"auto","active_multi":null,"active_scroll":"auto","active_tap":"auto","tools":[{"id":"3174"},{"id":"3192"},{"id":"3193"},{"id":"3194"},{"id":"3195"},{"id":"3196"}]},"id":"3198","type":"Toolbar"},{"attributes":{},"id":"3206","type":"Selection"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05656","sizing_mode":"stretch_width"},"id":"3233","type":"Spacer"},{"attributes":{"axis":{"id":"3184"},"grid_line_color":null,"ticker":null},"id":"3187","type":"Grid"},{"attributes":{"end":2016.0,"reset_end":2016.0,"reset_start":2010.0,"start":2010.0,"tags":[[["year","year",null]]]},"id":"3172","type":"Range1d"}],"root_ids":["3170"]},"title":"Bokeh Application","version":"2.1.1"}};
  var render_items = [{"docid":"2f427bad-7663-4037-a99f-e1bfa28f3f23","root_ids":["3170"],"roots":{"3170":"dedf9170-6329-4eb1-9419-5767e9c7b18f"}}];
  root.Bokeh.embed.embed_items_notebook(docs_json, render_items);
  }
if (root.Bokeh !== undefined) {
    embed_document(root);
  } else {
    var attempts = 0;
    var timer = setInterval(function(root) {
      if (root.Bokeh !== undefined) {
        clearInterval(timer);
        embed_document(root);
      } else if (document.readyState == "complete") {
        attempts++;
        if (attempts > 100) {
          clearInterval(timer);
          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
        }
      }
    }, 10, root)
  }
})(window);</script>



- - - 

## Average Prices by Neighborhood

In this section, you will use hvplot to create an interactive visulization of the Average Prices with a dropdown selector for the neighborhood.

Hint: It will be easier to create a new DataFrame from grouping the data and calculating the mean prices for each year and neighborhood


```python
# Group by year and neighborhood and then create a new dataframe of the mean values
load_data3 = sfo_data.groupby(['year', 'neighborhood']).mean()
load_data3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>sale_price_sqr_foot</th>
      <th>housing_units</th>
      <th>gross_rent</th>
    </tr>
    <tr>
      <th>year</th>
      <th>neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">2010</th>
      <th>Alamo Square</th>
      <td>291.182945</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>Anza Vista</th>
      <td>267.932583</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>Bayview</th>
      <td>170.098665</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>Buena Vista Park</th>
      <td>347.394919</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
    <tr>
      <th>Central Richmond</th>
      <td>319.027623</td>
      <td>372560</td>
      <td>1239</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Use hvplot to create an interactive line chart of the average price per sq ft.
# The plot should have a dropdown selector for the neighborhood
load_data3.hvplot(x = 'year', y = 'sale_price_sqr_foot', groupby ='neighborhood', kind='line') 
```




<div id='3275'>





  <div class="bk-root" id="42ab2b48-8f03-455f-a172-25a7b4c81e5d" data-root-id="3275"></div>
</div>
<script type="application/javascript">(function(root) {
  function embed_document(root) {
  var docs_json = {"a9653c6c-daab-412e-9fc7-84d0281fdd7b":{"roots":{"references":[{"attributes":{},"id":"3290","type":"BasicTicker"},{"attributes":{"margin":[5,5,5,5],"name":"VSpacer05786","sizing_mode":"stretch_height"},"id":"3344","type":"Spacer"},{"attributes":{"children":[{"id":"3346"}],"css_classes":["panel-widget-box"],"margin":[5,5,5,5],"name":"WidgetBox05781"},"id":"3345","type":"Column"},{"attributes":{"children":[{"id":"3276"},{"id":"3280"},{"id":"3342"},{"id":"3343"}],"margin":[0,0,0,0],"name":"Row05780"},"id":"3275","type":"Row"},{"attributes":{},"id":"3311","type":"Selection"},{"attributes":{},"id":"3294","type":"BasicTicker"},{"attributes":{"axis":{"id":"3293"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"3296","type":"Grid"},{"attributes":{"active_drag":"auto","active_inspect":"auto","active_multi":null,"active_scroll":"auto","active_tap":"auto","tools":[{"id":"3279"},{"id":"3297"},{"id":"3298"},{"id":"3299"},{"id":"3300"},{"id":"3301"}]},"id":"3303","type":"Toolbar"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05789","sizing_mode":"stretch_width"},"id":"3276","type":"Spacer"},{"attributes":{"client_comm_id":"2119556002cf45da9a34826958e723b3","comm_id":"3e5cc4a41cf740149ac178bf85864294","plot_id":"3275"},"id":"3372","type":"panel.models.comm_manager.CommManager"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","top_units":"screen"},"id":"3302","type":"BoxAnnotation"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer05790","sizing_mode":"stretch_width"},"id":"3342","type":"Spacer"},{"attributes":{"end":644.0175329447045,"reset_end":644.0175329447045,"reset_start":141.1976609302527,"start":141.1976609302527,"tags":[[["sale_price_sqr_foot","sale_price_sqr_foot",null]]]},"id":"3278","type":"Range1d"},{"attributes":{"callback":null,"renderers":[{"id":"3316"}],"tags":["hv_created"],"tooltips":[["year","@{year}"],["sale_price_sqr_foot","@{sale_price_sqr_foot}"]]},"id":"3279","type":"HoverTool"},{"attributes":{},"id":"3333","type":"UnionRenderers"},{"attributes":{"children":[{"id":"3344"},{"id":"3345"},{"id":"3347"}],"margin":[0,0,0,0],"name":"Column05788"},"id":"3343","type":"Column"},{"attributes":{"data_source":{"id":"3310"},"glyph":{"id":"3313"},"hover_glyph":null,"muted_glyph":{"id":"3315"},"nonselection_glyph":{"id":"3314"},"selection_glyph":null,"view":{"id":"3317"}},"id":"3316","type":"GlyphRenderer"},{"attributes":{"align":null,"below":[{"id":"3289"}],"center":[{"id":"3292"},{"id":"3296"}],"left":[{"id":"3293"}],"margin":null,"min_border_bottom":10,"min_border_left":10,"min_border_right":10,"min_border_top":10,"plot_height":300,"plot_width":700,"renderers":[{"id":"3316"}],"sizing_mode":"fixed","title":{"id":"3281"},"toolbar":{"id":"3303"},"x_range":{"id":"3277"},"x_scale":{"id":"3285"},"y_range":{"id":"3278"},"y_scale":{"id":"3287"}},"id":"3280","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"3297","type":"SaveTool"},{"attributes":{},"id":"3285","type":"LinearScale"},{"attributes":{"margin":[5,5,5,5],"name":"VSpacer05787","sizing_mode":"stretch_height"},"id":"3347","type":"Spacer"},{"attributes":{},"id":"3320","type":"BasicTickFormatter"},{"attributes":{},"id":"3299","type":"WheelZoomTool"},{"attributes":{},"id":"3298","type":"PanTool"},{"attributes":{"line_alpha":0.1,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3314","type":"Line"},{"attributes":{"text":"neighborhood: Alamo Square","text_color":{"value":"black"},"text_font_size":{"value":"12pt"}},"id":"3281","type":"Title"},{"attributes":{"end":2016.0,"reset_end":2016.0,"reset_start":2010.0,"start":2010.0,"tags":[[["year","year",null]]]},"id":"3277","type":"Range1d"},{"attributes":{"overlay":{"id":"3302"}},"id":"3300","type":"BoxZoomTool"},{"attributes":{},"id":"3287","type":"LinearScale"},{"attributes":{},"id":"3301","type":"ResetTool"},{"attributes":{"data":{"sale_price_sqr_foot":{"__ndarray__":"Dkc7WO0yckCafszcbwhxQIGRs5ot42ZAJzog0LQ8eEAWMinKGEd+QI0V5FDt0IJAVCHcmLVPdUA=","dtype":"float64","order":"little","shape":[7]},"year":[2010,2011,2012,2013,2014,2015,2016]},"selected":{"id":"3311"},"selection_policy":{"id":"3333"}},"id":"3310","type":"ColumnDataSource"},{"attributes":{"source":{"id":"3310"}},"id":"3317","type":"CDSView"},{"attributes":{},"id":"3318","type":"BasicTickFormatter"},{"attributes":{"axis_label":"sale_price_sqr_foot","bounds":"auto","formatter":{"id":"3320"},"major_label_orientation":"horizontal","ticker":{"id":"3294"}},"id":"3293","type":"LinearAxis"},{"attributes":{"line_alpha":0.2,"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3315","type":"Line"},{"attributes":{"margin":[20,20,20,20],"min_width":250,"options":["Alamo Square","Anza Vista","Bayview","Buena Vista Park","Central Richmond","Central Sunset","Corona Heights","Cow Hollow","Croker Amazon","Diamond Heights","Downtown ","Eureka Valley/Dolores Heights","Excelsior","Financial District North","Financial District South","Forest Knolls","Glen Park","Golden Gate Heights","Haight Ashbury","Hayes Valley","Hunters Point","Ingleside ","Inner Mission","Inner Parkside","Inner Richmond","Inner Sunset","Jordan Park/Laurel Heights","Lake --The Presidio","Lone Mountain","Lower Pacific Heights","Marina","Miraloma Park","Mission Bay","Mission Dolores","Mission Terrace","Nob Hill","Noe Valley","Oceanview","Outer Parkside","Outer Richmond ","Outer Sunset","Pacific Heights","Park North","Parkside","Parnassus/Ashbury Heights","Portola","Potrero Hill","Presidio Heights","Russian Hill","South Beach","South of Market","Sunnyside","Telegraph Hill","Twin Peaks","Union Square District","Van Ness/ Civic Center","West Portal","Western Addition","Yerba Buena","Bernal Heights ","Clarendon Heights","Duboce Triangle","Ingleside Heights","North Beach","North Waterfront","Outer Mission","Westwood Highlands","Merced Heights","Midtown Terrace","Visitacion Valley","Silver Terrace","Westwood Park","Bayview Heights"],"title":"neighborhood","value":"Alamo Square","width":250},"id":"3346","type":"Select"},{"attributes":{"axis":{"id":"3289"},"grid_line_color":null,"ticker":null},"id":"3292","type":"Grid"},{"attributes":{"axis_label":"year","bounds":"auto","formatter":{"id":"3318"},"major_label_orientation":"horizontal","ticker":{"id":"3290"}},"id":"3289","type":"LinearAxis"},{"attributes":{"line_color":"#1f77b3","line_width":2,"x":{"field":"year"},"y":{"field":"sale_price_sqr_foot"}},"id":"3313","type":"Line"}],"root_ids":["3275","3372"]},"title":"Bokeh Application","version":"2.1.1"}};
  var render_items = [{"docid":"a9653c6c-daab-412e-9fc7-84d0281fdd7b","root_ids":["3275"],"roots":{"3275":"42ab2b48-8f03-455f-a172-25a7b4c81e5d"}}];
  root.Bokeh.embed.embed_items_notebook(docs_json, render_items);
  }
if (root.Bokeh !== undefined) {
    embed_document(root);
  } else {
    var attempts = 0;
    var timer = setInterval(function(root) {
      if (root.Bokeh !== undefined) {
        clearInterval(timer);
        embed_document(root);
      } else if (document.readyState == "complete") {
        attempts++;
        if (attempts > 100) {
          clearInterval(timer);
          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
        }
      }
    }, 10, root)
  }
})(window);</script>



- - - 

## The Top 10 Most Expensive Neighborhoods

In this section, you will need to calculate the mean sale price for each neighborhood and then sort the values to obtain the top 10 most expensive neighborhoods on average. Plot the results as a bar chart.


```python
# Getting the data from the top 10 expensive neighborhoods
load_data4 = load_data3.sort_values(by ='sale_price_sqr_foot', ascending = False).head(10)
load_data4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>sale_price_sqr_foot</th>
      <th>housing_units</th>
      <th>gross_rent</th>
    </tr>
    <tr>
      <th>year</th>
      <th>neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015</th>
      <th>Union Square District</th>
      <td>2258.702832</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">2016</th>
      <th>Presidio Heights</th>
      <td>1465.968586</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>Merced Heights</th>
      <td>1416.666667</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>2013</th>
      <th>Union Square District</th>
      <td>1290.472107</td>
      <td>378401</td>
      <td>2971</td>
    </tr>
    <tr>
      <th>2014</th>
      <th>Miraloma Park</th>
      <td>1267.766203</td>
      <td>380348</td>
      <td>3528</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">2016</th>
      <th>Parnassus/Ashbury Heights</th>
      <td>1207.997485</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>Outer Richmond</th>
      <td>1196.645437</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>2015</th>
      <th>Marina</th>
      <td>1132.837361</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
    <tr>
      <th>2014</th>
      <th>South of Market</th>
      <td>1119.838877</td>
      <td>380348</td>
      <td>3528</td>
    </tr>
    <tr>
      <th>2015</th>
      <th>Corona Heights</th>
      <td>1100.791194</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plotting the data from the top 10 expensive neighborhoods
load_data4.hvplot.bar(x = 'neighborhood', y = 'sale_price_sqr_foot')
```




<div id='3891'>





  <div class="bk-root" id="cfd094db-5518-4b0a-80ea-bd911b7ee8b1" data-root-id="3891"></div>
</div>
<script type="application/javascript">(function(root) {
  function embed_document(root) {
  var docs_json = {"74a5aeaa-f629-411b-af76-fda3cae2f44f":{"roots":{"references":[{"attributes":{},"id":"3906","type":"CategoricalTicker"},{"attributes":{"fill_alpha":{"value":0.2},"fill_color":{"value":"#1f77b3"},"line_alpha":{"value":0.2},"top":{"field":"sale_price_sqr_foot"},"width":{"value":0.8},"x":{"field":"neighborhood"}},"id":"3930","type":"VBar"},{"attributes":{"axis_label":"sale_price_sqr_foot","bounds":"auto","formatter":{"id":"3935"},"major_label_orientation":"horizontal","ticker":{"id":"3909"}},"id":"3908","type":"LinearAxis"},{"attributes":{"source":{"id":"3925"}},"id":"3932","type":"CDSView"},{"attributes":{},"id":"3909","type":"BasicTicker"},{"attributes":{"axis":{"id":"3908"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"3911","type":"Grid"},{"attributes":{"active_drag":"auto","active_inspect":"auto","active_multi":null,"active_scroll":"auto","active_tap":"auto","tools":[{"id":"3895"},{"id":"3912"},{"id":"3913"},{"id":"3914"},{"id":"3915"},{"id":"3916"}]},"id":"3918","type":"Toolbar"},{"attributes":{},"id":"3933","type":"CategoricalTickFormatter"},{"attributes":{"data":{"neighborhood":["Union Square District","Presidio Heights","Merced Heights","Union Square District","Miraloma Park","Parnassus/Ashbury Heights","Outer Richmond ","Marina","South of Market","Corona Heights"],"sale_price_sqr_foot":{"__ndarray__":"CX+Y2WeloUCHJRzV3+eWQKyqqqqqIpZAML7sb+MplEBcSWyXEM+TQGKfoWz935JAoL9q7ZSykkCNogt1WbORQLyhpwJbf5FAjW2sLiozkUA=","dtype":"float64","order":"little","shape":[10]}},"selected":{"id":"3926"},"selection_policy":{"id":"3944"}},"id":"3925","type":"ColumnDataSource"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","top_units":"screen"},"id":"3917","type":"BoxAnnotation"},{"attributes":{},"id":"3926","type":"Selection"},{"attributes":{},"id":"3944","type":"UnionRenderers"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer07025","sizing_mode":"stretch_width"},"id":"3953","type":"Spacer"},{"attributes":{"end":2374.4939958311456,"reset_end":2374.4939958311456,"reset_start":0.0,"tags":[[["sale_price_sqr_foot","sale_price_sqr_foot",null]]]},"id":"3894","type":"Range1d"},{"attributes":{"align":null,"below":[{"id":"3905"}],"center":[{"id":"3907"},{"id":"3911"}],"left":[{"id":"3908"}],"margin":null,"min_border_bottom":10,"min_border_left":10,"min_border_right":10,"min_border_top":10,"plot_height":300,"plot_width":700,"renderers":[{"id":"3931"}],"sizing_mode":"fixed","title":{"id":"3897"},"toolbar":{"id":"3918"},"x_range":{"id":"3893"},"x_scale":{"id":"3901"},"y_range":{"id":"3894"},"y_scale":{"id":"3903"}},"id":"3896","subtype":"Figure","type":"Plot"},{"attributes":{"factors":["Union Square District","Presidio Heights","Merced Heights","Miraloma Park","Parnassus/Ashbury Heights","Outer Richmond ","Marina","South of Market","Corona Heights"],"tags":[[["neighborhood","neighborhood",null]]]},"id":"3893","type":"FactorRange"},{"attributes":{},"id":"3912","type":"SaveTool"},{"attributes":{"children":[{"id":"3892"},{"id":"3896"},{"id":"3953"}],"margin":[0,0,0,0],"name":"Row07020","tags":["embedded"]},"id":"3891","type":"Row"},{"attributes":{},"id":"3901","type":"CategoricalScale"},{"attributes":{},"id":"3914","type":"WheelZoomTool"},{"attributes":{},"id":"3913","type":"PanTool"},{"attributes":{"text":"","text_color":{"value":"black"},"text_font_size":{"value":"12pt"}},"id":"3897","type":"Title"},{"attributes":{"overlay":{"id":"3917"}},"id":"3915","type":"BoxZoomTool"},{"attributes":{"callback":null,"renderers":[{"id":"3931"}],"tags":["hv_created"],"tooltips":[["neighborhood","@{neighborhood}"],["sale_price_sqr_foot","@{sale_price_sqr_foot}"]]},"id":"3895","type":"HoverTool"},{"attributes":{},"id":"3903","type":"LinearScale"},{"attributes":{"margin":[5,5,5,5],"name":"HSpacer07024","sizing_mode":"stretch_width"},"id":"3892","type":"Spacer"},{"attributes":{},"id":"3935","type":"BasicTickFormatter"},{"attributes":{},"id":"3916","type":"ResetTool"},{"attributes":{"axis_label":"neighborhood","bounds":"auto","formatter":{"id":"3933"},"major_label_orientation":"horizontal","ticker":{"id":"3906"}},"id":"3905","type":"CategoricalAxis"},{"attributes":{"fill_color":{"value":"#1f77b3"},"top":{"field":"sale_price_sqr_foot"},"width":{"value":0.8},"x":{"field":"neighborhood"}},"id":"3928","type":"VBar"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b3"},"line_alpha":{"value":0.1},"top":{"field":"sale_price_sqr_foot"},"width":{"value":0.8},"x":{"field":"neighborhood"}},"id":"3929","type":"VBar"},{"attributes":{"axis":{"id":"3905"},"grid_line_color":null,"ticker":null},"id":"3907","type":"Grid"},{"attributes":{"data_source":{"id":"3925"},"glyph":{"id":"3928"},"hover_glyph":null,"muted_glyph":{"id":"3930"},"nonselection_glyph":{"id":"3929"},"selection_glyph":null,"view":{"id":"3932"}},"id":"3931","type":"GlyphRenderer"}],"root_ids":["3891"]},"title":"Bokeh Application","version":"2.1.1"}};
  var render_items = [{"docid":"74a5aeaa-f629-411b-af76-fda3cae2f44f","root_ids":["3891"],"roots":{"3891":"cfd094db-5518-4b0a-80ea-bd911b7ee8b1"}}];
  root.Bokeh.embed.embed_items_notebook(docs_json, render_items);
  }
if (root.Bokeh !== undefined) {
    embed_document(root);
  } else {
    var attempts = 0;
    var timer = setInterval(function(root) {
      if (root.Bokeh !== undefined) {
        clearInterval(timer);
        embed_document(root);
      } else if (document.readyState == "complete") {
        attempts++;
        if (attempts > 100) {
          clearInterval(timer);
          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
        }
      }
    }, 10, root)
  }
})(window);</script>



- - - 

## Parallel Coordinates and Parallel Categories Analysis

In this section, you will use plotly express to create parallel coordinates and parallel categories visualizations so that investors can interactively filter and explore various factors related to the sales price of the neighborhoods. 

Using the DataFrame of Average values per neighborhood (calculated above), create the following visualizations:
1. Create a Parallel Coordinates Plot
2. Create a Parallel Categories Plot


```python
df =load_data4.groupby("year").head()
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>sale_price_sqr_foot</th>
      <th>housing_units</th>
      <th>gross_rent</th>
    </tr>
    <tr>
      <th>year</th>
      <th>neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015</th>
      <th>Union Square District</th>
      <td>2258.702832</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">2016</th>
      <th>Presidio Heights</th>
      <td>1465.968586</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>Merced Heights</th>
      <td>1416.666667</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>2013</th>
      <th>Union Square District</th>
      <td>1290.472107</td>
      <td>378401</td>
      <td>2971</td>
    </tr>
    <tr>
      <th>2014</th>
      <th>Miraloma Park</th>
      <td>1267.766203</td>
      <td>380348</td>
      <td>3528</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">2016</th>
      <th>Parnassus/Ashbury Heights</th>
      <td>1207.997485</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>Outer Richmond</th>
      <td>1196.645437</td>
      <td>384242</td>
      <td>4390</td>
    </tr>
    <tr>
      <th>2015</th>
      <th>Marina</th>
      <td>1132.837361</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
    <tr>
      <th>2014</th>
      <th>South of Market</th>
      <td>1119.838877</td>
      <td>380348</td>
      <td>3528</td>
    </tr>
    <tr>
      <th>2015</th>
      <th>Corona Heights</th>
      <td>1100.791194</td>
      <td>382295</td>
      <td>3739</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Parallel Coordinates Plot
px.parallel_coordinates(load_data4)
```


<div>                            <div id="33df8ec2-65fe-4c9b-aa25-55d84b63158d" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("33df8ec2-65fe-4c9b-aa25-55d84b63158d")) {                    Plotly.newPlot(                        "33df8ec2-65fe-4c9b-aa25-55d84b63158d",                        [{"dimensions": [{"label": "sale_price_sqr_foot", "values": [2258.702831998355, 1465.9685863874345, 1416.666666666667, 1290.472106646641, 1267.7662026328826, 1207.997484708169, 1196.645436923929, 1132.8373605554546, 1119.8388773148026, 1100.7911936704506]}, {"label": "housing_units", "values": [382295, 384242, 384242, 378401, 380348, 384242, 384242, 382295, 380348, 382295]}, {"label": "gross_rent", "values": [3739, 4390, 4390, 2971, 3528, 4390, 4390, 3739, 3528, 3739]}], "domain": {"x": [0.0, 1.0], "y": [0.0, 1.0]}, "name": "", "type": "parcoords"}],                        {"legend": {"tracegroupgap": 0}, "margin": {"t": 60}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('33df8ec2-65fe-4c9b-aa25-55d84b63158d');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
# Parallel Categories Plot
px.parallel_categories(load_data4, color_continuous_scale=px.colors.sequential.Inferno)
```


<div>                            <div id="fbfd971d-6682-440d-bb6b-6df339c75312" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("fbfd971d-6682-440d-bb6b-6df339c75312")) {                    Plotly.newPlot(                        "fbfd971d-6682-440d-bb6b-6df339c75312",                        [{"dimensions": [{"label": "sale_price_sqr_foot", "values": [2258.702831998355, 1465.9685863874345, 1416.666666666667, 1290.472106646641, 1267.7662026328826, 1207.997484708169, 1196.645436923929, 1132.8373605554546, 1119.8388773148026, 1100.7911936704506]}, {"label": "housing_units", "values": [382295, 384242, 384242, 378401, 380348, 384242, 384242, 382295, 380348, 382295]}, {"label": "gross_rent", "values": [3739, 4390, 4390, 2971, 3528, 4390, 4390, 3739, 3528, 3739]}], "domain": {"x": [0.0, 1.0], "y": [0.0, 1.0]}, "name": "", "type": "parcats"}],                        {"legend": {"tracegroupgap": 0}, "margin": {"t": 60}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('fbfd971d-6682-440d-bb6b-6df339c75312');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


- - - 

## Neighborhood Map

In this section, you will read in neighboor location data and build an interactive map with the average prices per neighborhood. Use a scatter_mapbox from plotly express to create the visualization. Remember, you will need your mapbox api key for this.

### Load Location Data


```python
# Load neighborhoods coordinates data
file_path = Path("Data/neighborhoods_coordinates.csv")
df_neighborhood_locations = pd.read_csv(file_path)
dn =df_neighborhood_locations.rename(columns={'Neighborhood': 'neighborhood'}).groupby("neighborhood").sum()
```

### Data Preparation

You will need to join the location data with the mean prices per neighborhood

1. Calculate the mean values for each neighborhood
2. Join the average values with the neighborhood locations


```python
# Calculate the mean values for each neighborhood
ds = (sfo_data[[ "year","sale_price_sqr_foot", "gross_rent", "housing_units", "neighborhood"]]).groupby("neighborhood").mean()
ds
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>sale_price_sqr_foot</th>
      <th>gross_rent</th>
      <th>housing_units</th>
    </tr>
    <tr>
      <th>neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alamo Square</th>
      <td>2013.000000</td>
      <td>366.020712</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Anza Vista</th>
      <td>2013.333333</td>
      <td>373.382198</td>
      <td>3031.833333</td>
      <td>379050.00</td>
    </tr>
    <tr>
      <th>Bayview</th>
      <td>2012.000000</td>
      <td>204.588623</td>
      <td>2318.400000</td>
      <td>376454.00</td>
    </tr>
    <tr>
      <th>Bayview Heights</th>
      <td>2015.000000</td>
      <td>590.792839</td>
      <td>3739.000000</td>
      <td>382295.00</td>
    </tr>
    <tr>
      <th>Bernal Heights</th>
      <td>2013.500000</td>
      <td>576.746488</td>
      <td>3080.333333</td>
      <td>379374.50</td>
    </tr>
    <tr>
      <th>Buena Vista Park</th>
      <td>2012.833333</td>
      <td>452.680591</td>
      <td>2698.833333</td>
      <td>378076.50</td>
    </tr>
    <tr>
      <th>Central Richmond</th>
      <td>2013.000000</td>
      <td>394.422399</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Central Sunset</th>
      <td>2013.000000</td>
      <td>423.687928</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Clarendon Heights</th>
      <td>2012.000000</td>
      <td>487.244886</td>
      <td>2250.500000</td>
      <td>376454.00</td>
    </tr>
    <tr>
      <th>Corona Heights</th>
      <td>2012.400000</td>
      <td>587.539067</td>
      <td>2472.000000</td>
      <td>377232.80</td>
    </tr>
    <tr>
      <th>Cow Hollow</th>
      <td>2013.000000</td>
      <td>665.964042</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Croker Amazon</th>
      <td>2012.833333</td>
      <td>303.004184</td>
      <td>2698.833333</td>
      <td>378076.50</td>
    </tr>
    <tr>
      <th>Diamond Heights</th>
      <td>2011.500000</td>
      <td>434.991739</td>
      <td>2016.000000</td>
      <td>375480.50</td>
    </tr>
    <tr>
      <th>Downtown</th>
      <td>2013.000000</td>
      <td>391.434378</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Duboce Triangle</th>
      <td>2013.000000</td>
      <td>502.599156</td>
      <td>2780.250000</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Eureka Valley/Dolores Heights</th>
      <td>2013.000000</td>
      <td>642.248671</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Excelsior</th>
      <td>2013.333333</td>
      <td>388.765927</td>
      <td>3031.833333</td>
      <td>379050.00</td>
    </tr>
    <tr>
      <th>Financial District North</th>
      <td>2013.000000</td>
      <td>391.362533</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Financial District South</th>
      <td>2012.400000</td>
      <td>455.836212</td>
      <td>2472.000000</td>
      <td>377232.80</td>
    </tr>
    <tr>
      <th>Forest Knolls</th>
      <td>2011.000000</td>
      <td>321.840837</td>
      <td>1781.500000</td>
      <td>374507.00</td>
    </tr>
    <tr>
      <th>Glen Park</th>
      <td>2013.166667</td>
      <td>623.826178</td>
      <td>2899.500000</td>
      <td>378725.50</td>
    </tr>
    <tr>
      <th>Golden Gate Heights</th>
      <td>2012.600000</td>
      <td>639.393557</td>
      <td>2601.400000</td>
      <td>377622.20</td>
    </tr>
    <tr>
      <th>Haight Ashbury</th>
      <td>2013.000000</td>
      <td>449.544762</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Hayes Valley</th>
      <td>2013.000000</td>
      <td>355.932828</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Hunters Point</th>
      <td>2012.500000</td>
      <td>170.624920</td>
      <td>2489.000000</td>
      <td>377427.50</td>
    </tr>
    <tr>
      <th>Ingleside</th>
      <td>2012.500000</td>
      <td>367.895144</td>
      <td>2509.000000</td>
      <td>377427.50</td>
    </tr>
    <tr>
      <th>Ingleside Heights</th>
      <td>2013.500000</td>
      <td>384.797928</td>
      <td>2960.000000</td>
      <td>379374.50</td>
    </tr>
    <tr>
      <th>Inner Mission</th>
      <td>2013.000000</td>
      <td>397.673715</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Inner Parkside</th>
      <td>2013.750000</td>
      <td>519.385604</td>
      <td>3224.000000</td>
      <td>379861.25</td>
    </tr>
    <tr>
      <th>Inner Richmond</th>
      <td>2013.000000</td>
      <td>378.594314</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Noe Valley</th>
      <td>2013.000000</td>
      <td>542.442913</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>North Beach</th>
      <td>2013.400000</td>
      <td>411.646876</td>
      <td>2990.800000</td>
      <td>379179.80</td>
    </tr>
    <tr>
      <th>North Waterfront</th>
      <td>2013.000000</td>
      <td>498.269755</td>
      <td>2818.400000</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Oceanview</th>
      <td>2012.333333</td>
      <td>330.097385</td>
      <td>2434.000000</td>
      <td>377103.00</td>
    </tr>
    <tr>
      <th>Outer Mission</th>
      <td>2013.500000</td>
      <td>242.370952</td>
      <td>2995.750000</td>
      <td>379374.50</td>
    </tr>
    <tr>
      <th>Outer Parkside</th>
      <td>2013.000000</td>
      <td>485.027013</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Outer Richmond</th>
      <td>2013.000000</td>
      <td>473.900773</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Outer Sunset</th>
      <td>2013.000000</td>
      <td>394.219032</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Pacific Heights</th>
      <td>2013.000000</td>
      <td>689.555817</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Park North</th>
      <td>2013.000000</td>
      <td>373.732856</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Parkside</th>
      <td>2012.500000</td>
      <td>336.172661</td>
      <td>2555.166667</td>
      <td>377427.50</td>
    </tr>
    <tr>
      <th>Parnassus/Ashbury Heights</th>
      <td>2013.000000</td>
      <td>632.740454</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Portola</th>
      <td>2012.000000</td>
      <td>327.113925</td>
      <td>2318.400000</td>
      <td>376454.00</td>
    </tr>
    <tr>
      <th>Potrero Hill</th>
      <td>2013.000000</td>
      <td>662.013613</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Presidio Heights</th>
      <td>2013.000000</td>
      <td>675.350212</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Russian Hill</th>
      <td>2013.000000</td>
      <td>608.983217</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Silver Terrace</th>
      <td>2014.000000</td>
      <td>170.292549</td>
      <td>3528.000000</td>
      <td>380348.00</td>
    </tr>
    <tr>
      <th>South Beach</th>
      <td>2011.666667</td>
      <td>650.124479</td>
      <td>2099.000000</td>
      <td>375805.00</td>
    </tr>
    <tr>
      <th>South of Market</th>
      <td>2013.000000</td>
      <td>570.271427</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Sunnyside</th>
      <td>2013.166667</td>
      <td>528.318332</td>
      <td>2899.500000</td>
      <td>378725.50</td>
    </tr>
    <tr>
      <th>Telegraph Hill</th>
      <td>2013.000000</td>
      <td>676.506578</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Twin Peaks</th>
      <td>2013.000000</td>
      <td>469.398626</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Union Square District</th>
      <td>2012.500000</td>
      <td>903.993258</td>
      <td>2555.166667</td>
      <td>377427.50</td>
    </tr>
    <tr>
      <th>Van Ness/ Civic Center</th>
      <td>2013.000000</td>
      <td>404.150180</td>
      <td>2817.285714</td>
      <td>378401.00</td>
    </tr>
    <tr>
      <th>Visitacion Valley</th>
      <td>2014.500000</td>
      <td>301.466180</td>
      <td>3657.000000</td>
      <td>381321.50</td>
    </tr>
    <tr>
      <th>West Portal</th>
      <td>2012.250000</td>
      <td>498.488485</td>
      <td>2515.500000</td>
      <td>376940.75</td>
    </tr>
    <tr>
      <th>Western Addition</th>
      <td>2012.500000</td>
      <td>307.562201</td>
      <td>2555.166667</td>
      <td>377427.50</td>
    </tr>
    <tr>
      <th>Westwood Highlands</th>
      <td>2012.000000</td>
      <td>533.703935</td>
      <td>2250.500000</td>
      <td>376454.00</td>
    </tr>
    <tr>
      <th>Westwood Park</th>
      <td>2015.000000</td>
      <td>687.087575</td>
      <td>3959.000000</td>
      <td>382295.00</td>
    </tr>
    <tr>
      <th>Yerba Buena</th>
      <td>2012.500000</td>
      <td>576.709848</td>
      <td>2555.166667</td>
      <td>377427.50</td>
    </tr>
  </tbody>
</table>
<p>73 rows × 4 columns</p>
</div>




```python
# Join the average values with the neighborhood locations
dl = ds.join(dn)
dl
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>sale_price_sqr_foot</th>
      <th>gross_rent</th>
      <th>housing_units</th>
      <th>Lat</th>
      <th>Lon</th>
    </tr>
    <tr>
      <th>neighborhood</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alamo Square</th>
      <td>2013.000000</td>
      <td>366.020712</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.791012</td>
      <td>-122.402100</td>
    </tr>
    <tr>
      <th>Anza Vista</th>
      <td>2013.333333</td>
      <td>373.382198</td>
      <td>3031.833333</td>
      <td>379050.00</td>
      <td>37.779598</td>
      <td>-122.443451</td>
    </tr>
    <tr>
      <th>Bayview</th>
      <td>2012.000000</td>
      <td>204.588623</td>
      <td>2318.400000</td>
      <td>376454.00</td>
      <td>37.734670</td>
      <td>-122.401060</td>
    </tr>
    <tr>
      <th>Bayview Heights</th>
      <td>2015.000000</td>
      <td>590.792839</td>
      <td>3739.000000</td>
      <td>382295.00</td>
      <td>37.728740</td>
      <td>-122.410980</td>
    </tr>
    <tr>
      <th>Bernal Heights</th>
      <td>2013.500000</td>
      <td>576.746488</td>
      <td>3080.333333</td>
      <td>379374.50</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Buena Vista Park</th>
      <td>2012.833333</td>
      <td>452.680591</td>
      <td>2698.833333</td>
      <td>378076.50</td>
      <td>37.768160</td>
      <td>-122.439330</td>
    </tr>
    <tr>
      <th>Central Richmond</th>
      <td>2013.000000</td>
      <td>394.422399</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.777890</td>
      <td>-122.445170</td>
    </tr>
    <tr>
      <th>Central Sunset</th>
      <td>2013.000000</td>
      <td>423.687928</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.749610</td>
      <td>-122.489990</td>
    </tr>
    <tr>
      <th>Clarendon Heights</th>
      <td>2012.000000</td>
      <td>487.244886</td>
      <td>2250.500000</td>
      <td>376454.00</td>
      <td>37.753310</td>
      <td>-122.447030</td>
    </tr>
    <tr>
      <th>Corona Heights</th>
      <td>2012.400000</td>
      <td>587.539067</td>
      <td>2472.000000</td>
      <td>377232.80</td>
      <td>37.785530</td>
      <td>-122.456000</td>
    </tr>
    <tr>
      <th>Cow Hollow</th>
      <td>2013.000000</td>
      <td>665.964042</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.792980</td>
      <td>-122.435790</td>
    </tr>
    <tr>
      <th>Croker Amazon</th>
      <td>2012.833333</td>
      <td>303.004184</td>
      <td>2698.833333</td>
      <td>378076.50</td>
      <td>37.722800</td>
      <td>-122.438690</td>
    </tr>
    <tr>
      <th>Diamond Heights</th>
      <td>2011.500000</td>
      <td>434.991739</td>
      <td>2016.000000</td>
      <td>375480.50</td>
      <td>37.728630</td>
      <td>-122.443050</td>
    </tr>
    <tr>
      <th>Downtown</th>
      <td>2013.000000</td>
      <td>391.434378</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Duboce Triangle</th>
      <td>2013.000000</td>
      <td>502.599156</td>
      <td>2780.250000</td>
      <td>378401.00</td>
      <td>37.769640</td>
      <td>-122.426110</td>
    </tr>
    <tr>
      <th>Eureka Valley/Dolores Heights</th>
      <td>2013.000000</td>
      <td>642.248671</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.755540</td>
      <td>-122.437790</td>
    </tr>
    <tr>
      <th>Excelsior</th>
      <td>2013.333333</td>
      <td>388.765927</td>
      <td>3031.833333</td>
      <td>379050.00</td>
      <td>37.728740</td>
      <td>-122.410980</td>
    </tr>
    <tr>
      <th>Financial District North</th>
      <td>2013.000000</td>
      <td>391.362533</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.791010</td>
      <td>-122.402100</td>
    </tr>
    <tr>
      <th>Financial District South</th>
      <td>2012.400000</td>
      <td>455.836212</td>
      <td>2472.000000</td>
      <td>377232.80</td>
      <td>37.791010</td>
      <td>-122.402100</td>
    </tr>
    <tr>
      <th>Forest Knolls</th>
      <td>2011.000000</td>
      <td>321.840837</td>
      <td>1781.500000</td>
      <td>374507.00</td>
      <td>37.757060</td>
      <td>-122.455090</td>
    </tr>
    <tr>
      <th>Glen Park</th>
      <td>2013.166667</td>
      <td>623.826178</td>
      <td>2899.500000</td>
      <td>378725.50</td>
      <td>37.728630</td>
      <td>-122.443050</td>
    </tr>
    <tr>
      <th>Golden Gate Heights</th>
      <td>2012.600000</td>
      <td>639.393557</td>
      <td>2601.400000</td>
      <td>377622.20</td>
      <td>37.757912</td>
      <td>-122.464020</td>
    </tr>
    <tr>
      <th>Haight Ashbury</th>
      <td>2013.000000</td>
      <td>449.544762</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.765250</td>
      <td>-122.435960</td>
    </tr>
    <tr>
      <th>Hayes Valley</th>
      <td>2013.000000</td>
      <td>355.932828</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.765250</td>
      <td>-122.435960</td>
    </tr>
    <tr>
      <th>Hunters Point</th>
      <td>2012.500000</td>
      <td>170.624920</td>
      <td>2489.000000</td>
      <td>377427.50</td>
      <td>37.725510</td>
      <td>-122.371780</td>
    </tr>
    <tr>
      <th>Ingleside</th>
      <td>2012.500000</td>
      <td>367.895144</td>
      <td>2509.000000</td>
      <td>377427.50</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Ingleside Heights</th>
      <td>2013.500000</td>
      <td>384.797928</td>
      <td>2960.000000</td>
      <td>379374.50</td>
      <td>37.721160</td>
      <td>-122.487070</td>
    </tr>
    <tr>
      <th>Inner Mission</th>
      <td>2013.000000</td>
      <td>397.673715</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.754160</td>
      <td>-122.419470</td>
    </tr>
    <tr>
      <th>Inner Parkside</th>
      <td>2013.750000</td>
      <td>519.385604</td>
      <td>3224.000000</td>
      <td>379861.25</td>
      <td>37.749610</td>
      <td>-122.489990</td>
    </tr>
    <tr>
      <th>Inner Richmond</th>
      <td>2013.000000</td>
      <td>378.594314</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.769112</td>
      <td>-122.483566</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Noe Valley</th>
      <td>2013.000000</td>
      <td>542.442913</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.753310</td>
      <td>-122.447030</td>
    </tr>
    <tr>
      <th>North Beach</th>
      <td>2013.400000</td>
      <td>411.646876</td>
      <td>2990.800000</td>
      <td>379179.80</td>
      <td>37.800550</td>
      <td>-122.404330</td>
    </tr>
    <tr>
      <th>North Waterfront</th>
      <td>2013.000000</td>
      <td>498.269755</td>
      <td>2818.400000</td>
      <td>378401.00</td>
      <td>37.800550</td>
      <td>-122.404330</td>
    </tr>
    <tr>
      <th>Oceanview</th>
      <td>2012.333333</td>
      <td>330.097385</td>
      <td>2434.000000</td>
      <td>377103.00</td>
      <td>37.719930</td>
      <td>-122.465950</td>
    </tr>
    <tr>
      <th>Outer Mission</th>
      <td>2013.500000</td>
      <td>242.370952</td>
      <td>2995.750000</td>
      <td>379374.50</td>
      <td>37.722800</td>
      <td>-122.438690</td>
    </tr>
    <tr>
      <th>Outer Parkside</th>
      <td>2013.000000</td>
      <td>485.027013</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.751700</td>
      <td>-122.446000</td>
    </tr>
    <tr>
      <th>Outer Richmond</th>
      <td>2013.000000</td>
      <td>473.900773</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Outer Sunset</th>
      <td>2013.000000</td>
      <td>394.219032</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.749610</td>
      <td>-122.489990</td>
    </tr>
    <tr>
      <th>Pacific Heights</th>
      <td>2013.000000</td>
      <td>689.555817</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.792980</td>
      <td>-122.435790</td>
    </tr>
    <tr>
      <th>Park North</th>
      <td>2013.000000</td>
      <td>373.732856</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.728380</td>
      <td>-122.478510</td>
    </tr>
    <tr>
      <th>Parkside</th>
      <td>2012.500000</td>
      <td>336.172661</td>
      <td>2555.166667</td>
      <td>377427.50</td>
      <td>37.749610</td>
      <td>-122.489990</td>
    </tr>
    <tr>
      <th>Parnassus/Ashbury Heights</th>
      <td>2013.000000</td>
      <td>632.740454</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.763550</td>
      <td>-122.457650</td>
    </tr>
    <tr>
      <th>Portola</th>
      <td>2012.000000</td>
      <td>327.113925</td>
      <td>2318.400000</td>
      <td>376454.00</td>
      <td>37.734670</td>
      <td>-122.401060</td>
    </tr>
    <tr>
      <th>Potrero Hill</th>
      <td>2013.000000</td>
      <td>662.013613</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.731960</td>
      <td>-122.383240</td>
    </tr>
    <tr>
      <th>Presidio Heights</th>
      <td>2013.000000</td>
      <td>675.350212</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.785530</td>
      <td>-122.456000</td>
    </tr>
    <tr>
      <th>Russian Hill</th>
      <td>2013.000000</td>
      <td>608.983217</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.792980</td>
      <td>-122.435790</td>
    </tr>
    <tr>
      <th>Silver Terrace</th>
      <td>2014.000000</td>
      <td>170.292549</td>
      <td>3528.000000</td>
      <td>380348.00</td>
      <td>37.734670</td>
      <td>-122.401060</td>
    </tr>
    <tr>
      <th>South Beach</th>
      <td>2011.666667</td>
      <td>650.124479</td>
      <td>2099.000000</td>
      <td>375805.00</td>
      <td>37.783230</td>
      <td>-122.400650</td>
    </tr>
    <tr>
      <th>South of Market</th>
      <td>2013.000000</td>
      <td>570.271427</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.791010</td>
      <td>-122.402100</td>
    </tr>
    <tr>
      <th>Sunnyside</th>
      <td>2013.166667</td>
      <td>528.318332</td>
      <td>2899.500000</td>
      <td>378725.50</td>
      <td>37.734150</td>
      <td>-122.457000</td>
    </tr>
    <tr>
      <th>Telegraph Hill</th>
      <td>2013.000000</td>
      <td>676.506578</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.800550</td>
      <td>-122.404330</td>
    </tr>
    <tr>
      <th>Twin Peaks</th>
      <td>2013.000000</td>
      <td>469.398626</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.753311</td>
      <td>-122.447029</td>
    </tr>
    <tr>
      <th>Union Square District</th>
      <td>2012.500000</td>
      <td>903.993258</td>
      <td>2555.166667</td>
      <td>377427.50</td>
      <td>37.791010</td>
      <td>-122.402100</td>
    </tr>
    <tr>
      <th>Van Ness/ Civic Center</th>
      <td>2013.000000</td>
      <td>404.150180</td>
      <td>2817.285714</td>
      <td>378401.00</td>
      <td>37.779510</td>
      <td>-122.420220</td>
    </tr>
    <tr>
      <th>Visitacion Valley</th>
      <td>2014.500000</td>
      <td>301.466180</td>
      <td>3657.000000</td>
      <td>381321.50</td>
      <td>37.728740</td>
      <td>-122.410980</td>
    </tr>
    <tr>
      <th>West Portal</th>
      <td>2012.250000</td>
      <td>498.488485</td>
      <td>2515.500000</td>
      <td>376940.75</td>
      <td>37.740260</td>
      <td>-122.463880</td>
    </tr>
    <tr>
      <th>Western Addition</th>
      <td>2012.500000</td>
      <td>307.562201</td>
      <td>2555.166667</td>
      <td>377427.50</td>
      <td>37.792980</td>
      <td>-122.435790</td>
    </tr>
    <tr>
      <th>Westwood Highlands</th>
      <td>2012.000000</td>
      <td>533.703935</td>
      <td>2250.500000</td>
      <td>376454.00</td>
      <td>37.734700</td>
      <td>-122.456854</td>
    </tr>
    <tr>
      <th>Westwood Park</th>
      <td>2015.000000</td>
      <td>687.087575</td>
      <td>3959.000000</td>
      <td>382295.00</td>
      <td>37.734150</td>
      <td>-122.457000</td>
    </tr>
    <tr>
      <th>Yerba Buena</th>
      <td>2012.500000</td>
      <td>576.709848</td>
      <td>2555.166667</td>
      <td>377427.50</td>
      <td>37.792980</td>
      <td>-122.396360</td>
    </tr>
  </tbody>
</table>
<p>73 rows × 6 columns</p>
</div>



### Mapbox Visualization

Plot the aveage values per neighborhood with a plotly express scatter_mapbox visualization.


```python
token = 'pk.eyJ1IjoiZmF6bGVoYW1lZW0iLCJhIjoiY2tneTdreWV4MGIyZTJ1bXNtd3E4dTNwZCJ9.V-zQBku8Dcjlk14FBqxPUg'
px.set_mapbox_access_token(token)
```


```python
# Create a scatter mapbox to analyze neighborhood info
map_plot = px.scatter_mapbox(dl, color ="gross_rent",lat = "Lat", lon = "Lon", size = "sale_price_sqr_foot", zoom=4)
map_plot.show()
```


<div>                            <div id="87145bdd-ef31-4e89-95e0-59c9acec2256" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("87145bdd-ef31-4e89-95e0-59c9acec2256")) {                    Plotly.newPlot(                        "87145bdd-ef31-4e89-95e0-59c9acec2256",                        [{"hovertemplate": "sale_price_sqr_foot=%{marker.size}<br>Lat=%{lat}<br>Lon=%{lon}<br>gross_rent=%{marker.color}<extra></extra>", "lat": [37.791012, 37.779598, 37.73467, 37.72874, null, 37.768159999999995, 37.77789, 37.74961, 37.75331, 37.78553, 37.79298, 37.7228, 37.728629999999995, null, 37.76964, 37.75554, 37.72874, 37.79101, 37.79101, 37.757059999999996, 37.728629999999995, 37.757912, 37.76525, 37.76525, 37.72551, null, 37.72116, 37.75416, 37.74961, 37.769112, 37.74961, 37.78553, 37.801520000000004, 37.7789, 37.79298, 37.79972, 37.71993, 37.75331, 37.73415, 37.783229999999996, 37.75184, 37.728629999999995, 37.79298, 37.75331, 37.80055, 37.80055, 37.71993, 37.7228, 37.7517, null, 37.74961, 37.79298, 37.72838, 37.74961, 37.76355, 37.73467, 37.73196, 37.78553, 37.79298, 37.73467, 37.783229999999996, 37.79101, 37.73415, 37.80055, 37.753311, 37.79101, 37.779509999999995, 37.72874, 37.74026, 37.79298, 37.7347, 37.73415, 37.79298], "legendgroup": "", "lon": [-122.4021, -122.443451, -122.40106000000002, -122.41098000000001, null, -122.43933, -122.44516999999999, -122.48998999999999, -122.44703, -122.456, -122.43579, -122.43869, -122.44305, null, -122.42611000000001, -122.43778999999999, -122.41098000000001, -122.4021, -122.4021, -122.45508999999998, -122.44305, -122.46401999999999, -122.43596000000001, -122.43596000000001, -122.37178, null, -122.48706999999999, -122.41946999999999, -122.48998999999999, -122.483566, -122.48997, -122.456, -122.45456999999999, -122.45496000000001, -122.43579, -122.46688999999999, -122.46595, -122.44703, -122.45700000000001, -122.40065, -122.42522, -122.44305, -122.43579, -122.44703, -122.40433, -122.40433, -122.46595, -122.43869, -122.446, null, -122.48998999999999, -122.43579, -122.47851000000001, -122.48998999999999, -122.45765, -122.40106000000002, -122.38323999999999, -122.456, -122.43579, -122.40106000000002, -122.40065, -122.4021, -122.45700000000001, -122.40433, -122.447029, -122.4021, -122.42022, -122.41098000000001, -122.46388, -122.43579, -122.456854, -122.45700000000001, -122.39636000000002], "marker": {"color": [2817.285714285714, 3031.8333333333335, 2318.4, 3739.0, 3080.3333333333335, 2698.8333333333335, 2817.285714285714, 2817.285714285714, 2250.5, 2472.0, 2817.285714285714, 2698.8333333333335, 2016.0, 2817.285714285714, 2780.25, 2817.285714285714, 3031.8333333333335, 2817.285714285714, 2472.0, 1781.5, 2899.5, 2601.4, 2817.285714285714, 2817.285714285714, 2489.0, 2509.0, 2960.0, 2817.285714285714, 3224.0, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2555.1666666666665, 2817.285714285714, 2817.285714285714, 3414.0, 2647.5, 2155.25, 2663.6666666666665, 2555.1666666666665, 3173.4, 2817.285714285714, 2817.285714285714, 2990.8, 2818.4, 2434.0, 2995.75, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2817.285714285714, 2318.4, 2817.285714285714, 2817.285714285714, 2817.285714285714, 3528.0, 2099.0, 2817.285714285714, 2899.5, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2817.285714285714, 3657.0, 2515.5, 2555.1666666666665, 2250.5, 3959.0, 2555.1666666666665], "coloraxis": "coloraxis", "size": [366.02071153227644, 373.38219782647707, 204.58862288246596, 590.7928388746802, 576.7464881132382, 452.6805909308442, 394.4223987800589, 423.6879277015824, 487.2448860262575, 587.5390673661739, 665.964041578323, 303.00418440849427, 434.99173944522124, 391.43437776742576, 502.59915555623616, 642.2486706357391, 388.76592700230754, 391.36253308010487, 455.83621223779153, 321.84083657398736, 623.826177537435, 639.3935574881156, 449.5447622856192, 355.9328279480578, 170.62491987132685, 367.8951440852775, 384.7979281346048, 397.67371473613446, 519.3856038526768, 378.59431396136455, 413.66751546215943, 529.3841850673389, 409.95435219297514, 478.2285530213679, 539.2379688783261, 583.7492694814549, 788.8448175872469, 550.5103482917151, 779.810842264425, 566.1922135483312, 418.9156225067234, 523.4662013248023, 458.2040944846015, 542.4429128151736, 411.646875881678, 498.26975500787677, 330.0973846552545, 242.37095202049667, 485.0270126111035, 473.90077331796317, 394.21903228550775, 689.5558168113664, 373.732856371763, 336.172661037069, 632.740453508577, 327.11392534647274, 662.0136128276529, 675.3502120510033, 608.9832172374425, 170.2925485152069, 650.1244791945729, 570.2714266991686, 528.3183317138463, 676.5065775293257, 469.39862649935156, 903.9932576720645, 404.1501801622257, 301.46617997450267, 498.4884848295011, 307.56220097996066, 533.7039354359513, 687.0875745178323, 576.709848378276], "sizemode": "area", "sizeref": 2.259983144180161}, "mode": "markers", "name": "", "showlegend": false, "subplot": "mapbox", "type": "scattermapbox"}],                        {"coloraxis": {"colorbar": {"title": {"text": "gross_rent"}}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "legend": {"itemsizing": "constant", "tracegroupgap": 0}, "mapbox": {"accesstoken": "pk.eyJ1IjoiZmF6bGVoYW1lZW0iLCJhIjoiY2tneTdreWV4MGIyZTJ1bXNtd3E4dTNwZCJ9.V-zQBku8Dcjlk14FBqxPUg", "center": {"lat": 37.76064079710145, "lon": -122.43826449275363}, "domain": {"x": [0.0, 1.0], "y": [0.0, 1.0]}, "zoom": 4}, "margin": {"t": 60}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('87145bdd-ef31-4e89-95e0-59c9acec2256');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python

```


<div>                            <div id="3a26da22-fcc0-446e-a525-d3770269d9e3" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("3a26da22-fcc0-446e-a525-d3770269d9e3")) {                    Plotly.newPlot(                        "3a26da22-fcc0-446e-a525-d3770269d9e3",                        [{"hovertemplate": "sale_price_sqr_foot=%{marker.size}<br>Lat=%{lat}<br>Lon=%{lon}<br>gross_rent=%{marker.color}<extra></extra>", "lat": [37.791012, 37.779598, 37.73467, 37.72874, null, 37.768159999999995, 37.77789, 37.74961, 37.75331, 37.78553, 37.79298, 37.7228, 37.728629999999995, null, 37.76964, 37.75554, 37.72874, 37.79101, 37.79101, 37.757059999999996, 37.728629999999995, 37.757912, 37.76525, 37.76525, 37.72551, null, 37.72116, 37.75416, 37.74961, 37.769112, 37.74961, 37.78553, 37.801520000000004, 37.7789, 37.79298, 37.79972, 37.71993, 37.75331, 37.73415, 37.783229999999996, 37.75184, 37.728629999999995, 37.79298, 37.75331, 37.80055, 37.80055, 37.71993, 37.7228, 37.7517, null, 37.74961, 37.79298, 37.72838, 37.74961, 37.76355, 37.73467, 37.73196, 37.78553, 37.79298, 37.73467, 37.783229999999996, 37.79101, 37.73415, 37.80055, 37.753311, 37.79101, 37.779509999999995, 37.72874, 37.74026, 37.79298, 37.7347, 37.73415, 37.79298], "legendgroup": "", "lon": [-122.4021, -122.443451, -122.40106000000002, -122.41098000000001, null, -122.43933, -122.44516999999999, -122.48998999999999, -122.44703, -122.456, -122.43579, -122.43869, -122.44305, null, -122.42611000000001, -122.43778999999999, -122.41098000000001, -122.4021, -122.4021, -122.45508999999998, -122.44305, -122.46401999999999, -122.43596000000001, -122.43596000000001, -122.37178, null, -122.48706999999999, -122.41946999999999, -122.48998999999999, -122.483566, -122.48997, -122.456, -122.45456999999999, -122.45496000000001, -122.43579, -122.46688999999999, -122.46595, -122.44703, -122.45700000000001, -122.40065, -122.42522, -122.44305, -122.43579, -122.44703, -122.40433, -122.40433, -122.46595, -122.43869, -122.446, null, -122.48998999999999, -122.43579, -122.47851000000001, -122.48998999999999, -122.45765, -122.40106000000002, -122.38323999999999, -122.456, -122.43579, -122.40106000000002, -122.40065, -122.4021, -122.45700000000001, -122.40433, -122.447029, -122.4021, -122.42022, -122.41098000000001, -122.46388, -122.43579, -122.456854, -122.45700000000001, -122.39636000000002], "marker": {"color": [2817.285714285714, 3031.8333333333335, 2318.4, 3739.0, 3080.3333333333335, 2698.8333333333335, 2817.285714285714, 2817.285714285714, 2250.5, 2472.0, 2817.285714285714, 2698.8333333333335, 2016.0, 2817.285714285714, 2780.25, 2817.285714285714, 3031.8333333333335, 2817.285714285714, 2472.0, 1781.5, 2899.5, 2601.4, 2817.285714285714, 2817.285714285714, 2489.0, 2509.0, 2960.0, 2817.285714285714, 3224.0, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2555.1666666666665, 2817.285714285714, 2817.285714285714, 3414.0, 2647.5, 2155.25, 2663.6666666666665, 2555.1666666666665, 3173.4, 2817.285714285714, 2817.285714285714, 2990.8, 2818.4, 2434.0, 2995.75, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2817.285714285714, 2318.4, 2817.285714285714, 2817.285714285714, 2817.285714285714, 3528.0, 2099.0, 2817.285714285714, 2899.5, 2817.285714285714, 2817.285714285714, 2555.1666666666665, 2817.285714285714, 3657.0, 2515.5, 2555.1666666666665, 2250.5, 3959.0, 2555.1666666666665], "coloraxis": "coloraxis", "size": [366.02071153227644, 373.38219782647707, 204.58862288246596, 590.7928388746802, 576.7464881132382, 452.6805909308442, 394.4223987800589, 423.6879277015824, 487.2448860262575, 587.5390673661739, 665.964041578323, 303.00418440849427, 434.99173944522124, 391.43437776742576, 502.59915555623616, 642.2486706357391, 388.76592700230754, 391.36253308010487, 455.83621223779153, 321.84083657398736, 623.826177537435, 639.3935574881156, 449.5447622856192, 355.9328279480578, 170.62491987132685, 367.8951440852775, 384.7979281346048, 397.67371473613446, 519.3856038526768, 378.59431396136455, 413.66751546215943, 529.3841850673389, 409.95435219297514, 478.2285530213679, 539.2379688783261, 583.7492694814549, 788.8448175872469, 550.5103482917151, 779.810842264425, 566.1922135483312, 418.9156225067234, 523.4662013248023, 458.2040944846015, 542.4429128151736, 411.646875881678, 498.26975500787677, 330.0973846552545, 242.37095202049667, 485.0270126111035, 473.90077331796317, 394.21903228550775, 689.5558168113664, 373.732856371763, 336.172661037069, 632.740453508577, 327.11392534647274, 662.0136128276529, 675.3502120510033, 608.9832172374425, 170.2925485152069, 650.1244791945729, 570.2714266991686, 528.3183317138463, 676.5065775293257, 469.39862649935156, 903.9932576720645, 404.1501801622257, 301.46617997450267, 498.4884848295011, 307.56220097996066, 533.7039354359513, 687.0875745178323, 576.709848378276], "sizemode": "area", "sizeref": 2.259983144180161}, "mode": "markers", "name": "", "showlegend": false, "subplot": "mapbox", "type": "scattermapbox"}],                        {"coloraxis": {"colorbar": {"title": {"text": "gross_rent"}}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "legend": {"itemsizing": "constant", "tracegroupgap": 0}, "mapbox": {"center": {"lat": 37.76064079710145, "lon": -122.43826449275363}, "domain": {"x": [0.0, 1.0], "y": [0.0, 1.0]}, "zoom": 8}, "margin": {"t": 60}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('3a26da22-fcc0-446e-a525-d3770269d9e3');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python

```
